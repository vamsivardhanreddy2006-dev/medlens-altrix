@echo off
cd /d "%~dp0"
if not defined PORT set "PORT=8001"
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" server.py
) else (
    python server.py
)
